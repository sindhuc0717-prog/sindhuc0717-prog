// Contact form validation and message

document.getElementById("contactForm").addEventListener("submit", function (e) {

  e.preventDefault();

  document.getElementById("formMessage").textContent = "Thanks for your message! 🎶";

  this.reset();

});